package com.example.demo.model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
